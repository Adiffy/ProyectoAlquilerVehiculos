package exceptions;


public class PlantaNoValidaException extends Exception {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PlantaNoValidaException(String message) {
		super(message);
		
	}



}
