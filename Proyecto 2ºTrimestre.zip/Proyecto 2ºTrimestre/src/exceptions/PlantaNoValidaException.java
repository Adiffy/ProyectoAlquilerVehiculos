package exceptions;

@SuppressWarnings("serial")
public class PlantaNoValidaException extends Exception {

	
	public PlantaNoValidaException(String message) {
		super(message);
		
	}



}
