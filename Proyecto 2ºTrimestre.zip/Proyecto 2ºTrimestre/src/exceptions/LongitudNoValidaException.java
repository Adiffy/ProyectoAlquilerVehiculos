package exceptions;

public class LongitudNoValidaException extends Exception {

	public LongitudNoValidaException() {
		// TODO Auto-generated constructor stub
	}

	public LongitudNoValidaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
 

}
