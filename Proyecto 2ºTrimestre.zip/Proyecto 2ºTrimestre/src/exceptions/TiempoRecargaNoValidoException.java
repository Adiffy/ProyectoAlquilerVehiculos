package exceptions;


public class TiempoRecargaNoValidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TiempoRecargaNoValidoException(String mensaje)
	{
		super(mensaje);
	}
}
