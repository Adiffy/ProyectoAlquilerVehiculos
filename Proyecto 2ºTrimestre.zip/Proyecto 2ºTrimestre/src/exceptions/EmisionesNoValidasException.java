package exceptions;

public class EmisionesNoValidasException extends Exception {

	 
		
		/**
	 * 
	 */
	private static final long serialVersionUID = 6250742858888430516L;

		public EmisionesNoValidasException(String mensaje)
		{
			super(mensaje);
		}
		
	

}
