package exceptions;



public class EmisionesNoValidasException extends Exception {

	 

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public EmisionesNoValidasException(String mensaje)
		{
			super(mensaje);
		}
		
	

}
