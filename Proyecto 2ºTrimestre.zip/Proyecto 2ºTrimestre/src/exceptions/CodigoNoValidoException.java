package exceptions;

public class CodigoNoValidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
