package exceptions;


public class CapacidadDeCargaNoValidaException extends Exception {



	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CapacidadDeCargaNoValidaException() {
		
	}
	
	public CapacidadDeCargaNoValidaException(String msg) {
		super(msg);
	}
}
