package exceptions;


public class PotenciaNoValidaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PotenciaNoValidaException(String mensaje)
	{
		super(mensaje);
	}
}
