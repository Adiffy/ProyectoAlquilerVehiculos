package exceptions;

public class NumPlazasNoValidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4811501593841050204L;

	public NumPlazasNoValidoException(String mensaje) {
		super(mensaje);
	}

}
