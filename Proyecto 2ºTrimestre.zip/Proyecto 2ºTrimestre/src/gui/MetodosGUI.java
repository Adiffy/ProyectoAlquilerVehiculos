package gui;

import javax.swing.JFrame;
import java.awt.*;

public class MetodosGUI {

	
	public static void centraVentana(JFrame ventana)
	{
			//Leemos el tama�o de la pantalla donde se ejecuta el programa
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
			//Hacemos los c�lculos para centrarlo y cambiamos su posici�n
		ventana.setLocation(dim.width/2-ventana.getSize().width/2, dim.height/2-ventana.getSize().height/2);
	}
}
