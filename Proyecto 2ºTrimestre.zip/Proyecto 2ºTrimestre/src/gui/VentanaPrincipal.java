package gui;

import java.awt.FlowLayout;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import accesoADatos.RepositorioOficina;
import clasesObjetos.Oficina;

public class VentanaPrincipal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;



	/**
	 * Constructor
	 * Crea el Jframe.
	 */
	public VentanaPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuPrincipal = new JMenuBar();
		setJMenuBar(menuPrincipal);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		//Creamos el logo
		JLabel lblLogo = new JLabel("");
		lblLogo.setIcon(new ImageIcon("recursos\\Europcar-Logo.svg.png"));
		//Lo ponemos de fondo
		contentPane.add(lblLogo);
		setContentPane(contentPane);
		
		
		
		DefaultComboBoxModel<Oficina> d = new DefaultComboBoxModel<Oficina>();
		try {
			//Intenta meter al DefaultComboBoxModel el ArrayList<Oficina>
			d.addAll(RepositorioOficina.listaOficinas());
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		
	}
}
