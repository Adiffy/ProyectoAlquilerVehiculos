package comparadores;

import java.util.Comparator;

import clases.Objetos.Cliente;

public class ComparaClientePorDNI implements Comparator<Cliente> {

	public ComparaClientePorDNI() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compare(Cliente o1, Cliente o2) {
		// TODO o1.getdni.CompareToIgnoreCase(o2.getdni))
		return 0;
	}

}
