package principal;

import java.util.Scanner;

import InterfazUsuario.Menus;
import clasesObjetos.*;
import exceptions.CarnetRequeridoInvalidoException;
import exceptions.CilindradaNoValidaException;
import exceptions.CodigoPostalException;
import exceptions.ConsumoNoValidoException;
import exceptions.EmisionesNoValidasException;
import exceptions.LetrasMatriculaNoValidasException;
import exceptions.LicenciaNoValidaException;
import exceptions.LongitudCadenaNoValidaException;
import exceptions.LongitudNoValidaException;
import exceptions.NumPlazasNoValidoException;
import exceptions.NumeroMatriculaNoValidoException;
import exceptions.PlantaNoValidaException;
import exceptions.PotenciaNoValidaException;
import exceptions.RecargoNoValidoException;
import exceptions.TiempoRecargaNoValidoException;
import exceptions.TipoNoValidoException;

public class Principal {

	
	public static void main(String[] args) {
		
		Empresa empresa = new Empresa();	//Creamos una empresa
		Scanner lector = new Scanner(System.in);
	
		//	String errorCrear = "Error al crear veh�culo - "+ Object.class;
		
		try {
			Menus.principal(empresa, lector);
		} catch (TipoNoValidoException | TiempoRecargaNoValidoException | LicenciaNoValidaException | CilindradaNoValidaException | CarnetRequeridoInvalidoException | EmisionesNoValidasException | ConsumoNoValidoException | PotenciaNoValidaException | RecargoNoValidoException | LetrasMatriculaNoValidasException | NumeroMatriculaNoValidoException | NumPlazasNoValidoException | LongitudNoValidaException | PlantaNoValidaException | CodigoPostalException | LongitudCadenaNoValidaException e) {
			e.getLocalizedMessage();
			e.printStackTrace();
		}
		
		
		}
	
	
	
	
	
}
	


