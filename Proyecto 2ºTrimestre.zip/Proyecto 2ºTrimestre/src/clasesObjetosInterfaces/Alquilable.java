package clasesObjetosInterfaces;

public interface Alquilable {

	
	public double precioAlquiler();
	
}
