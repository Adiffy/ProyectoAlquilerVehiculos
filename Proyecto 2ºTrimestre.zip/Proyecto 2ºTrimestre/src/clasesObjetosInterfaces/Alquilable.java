package clasesObjetosInterfaces;

public interface Alquilable {
	int precioBase = 10;
	int porcentaje = (15*(precioBase))/100;
	
	public double PrecioAlquiler();
	
}
