package accesoADatos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.GregorianCalendar;

import clasesObjetos.Empleado;
import clasesObjetos.Oficina;
import exceptions.CarnetRequeridoInvalidoException;
import exceptions.LongitudCadenaNoValidaException;

public class RepositorioEmpleado {

	/**
	 * 
	 * @param dni El {@code String} que es el dni del empleado
	 * @return El empleado cuyo DNI es el escrito
	 */
	public static Empleado leeEmpleado(String dni)
	{
		PreparedStatement st = null;
		ResultSet rs;
		Empleado emple = null;	//Primero sacamos atributos generales de -> PERSONA
		String sql="SELECT * FROM Persona WHERE DNI=?";
		
		//TODO averiguar si existe para hacer UPDATE / INSERT
		try {
			st = EmpresaDB.conn.prepareStatement(sql);
			st.setString(1, dni);
			rs = st.executeQuery();
			
			while (rs.next())
			{
				//Solo va a devolver 1(porque estamos preguntando por la PK) asi q no hay problema de sobre escritura
				 String Dni = rs.getString("Dni");
				 String nombre = rs.getString("Nombre");
				 String ap1 = rs.getString("Ap1");
				 String ap2 = rs.getString("Ap2");
				 String o = rs.getString("Oficina");	//Obtenemos el c�digo de la oficina
				 Oficina Ofi = RepositorioOficina.leeOficina(o);	//Encontramos la oficina
			
				 rs.close();
				 //Ahora Extraemos los datos de EMPLEADO
				 sql = "SELECT * FROM Empleado WHERE DNI_PERSONA=?";
				 st = EmpresaDB.conn.prepareStatement(sql);
				 st.setString(1, dni);
				 rs = st.executeQuery();
				 
				 while (rs.next())
				 {
					 //Obtenemos la fecha de alta del trabajador
					 Date fechaAlta = rs.getDate("Fecha_alta");
					 //Lo pasamos a GregorianCalendar
					 GregorianCalendar fechAlta = new GregorianCalendar();
					 fechAlta.setTime(fechaAlta);
					 try {
						emple = new Empleado(Dni, nombre, ap1, ap2, fechAlta, Ofi);
					} catch (CarnetRequeridoInvalidoException e) {
						// Carnet Inv�lido
						e.printStackTrace();
					} catch (LongitudCadenaNoValidaException e) {
						// Longitud inv�lida
						e.printStackTrace();
					} 
				 }
				
			}
			//Cerramos la conexi�n
			st.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return emple;
	}
}
