package clases;

import java.util.TreeMap;

public class Empresa {

	//Propiedades
	private TreeMap<Persona, Vehiculo> Oficina;
	
}
