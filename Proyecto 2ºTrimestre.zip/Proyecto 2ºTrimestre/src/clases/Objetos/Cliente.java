package clases.Objetos;

public class Cliente {

	public Cliente() {
		// TODO Auto-generated constructor stub
	}

}
