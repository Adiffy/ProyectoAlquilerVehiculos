package operadores;

import clasesObjetosInterfaces.Coche;

@SuppressWarnings("unused")
public class CalculoMatematico {

/*	public static double CalculaPrecio(Object o)
	{
		int porcentaje = 0;
		Vehiculo trabajo =  (Vehiculo) o; // Lo tratamos como veh�culo
		
		if (trabajo.isElectrico())
		{
			//Aplicamos el 15% 
			porcentaje = (15*trabajo.precioBase)/100;
		}
		
		return (trabajo.precioBase+porcentaje);
	}*/

}
